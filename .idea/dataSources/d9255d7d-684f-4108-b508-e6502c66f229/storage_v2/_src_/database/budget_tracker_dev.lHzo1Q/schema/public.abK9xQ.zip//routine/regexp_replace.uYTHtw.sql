create function regexp_replace(string citext, pattern citext, replacement text, flags text) returns text
    immutable
    strict
    parallel safe
    language sql
RETURN regexp_replace((string)::text, (pattern)::text, replacement, CASE WHEN (strpos(flags, 'c'::text) = 0) THEN (flags || 'i'::text) ELSE flags END);

alter function regexp_replace(citext, citext, text, text) owner to postgres;

