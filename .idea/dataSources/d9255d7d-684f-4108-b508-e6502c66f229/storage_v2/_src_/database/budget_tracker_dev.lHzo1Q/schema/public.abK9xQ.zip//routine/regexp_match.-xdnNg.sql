create function regexp_match(string citext, pattern citext, flags text) returns text[]
    immutable
    strict
    parallel safe
    language sql
RETURN regexp_match((string)::text, (pattern)::text, CASE WHEN (strpos(flags, 'c'::text) = 0) THEN (flags || 'i'::text) ELSE flags END);

alter function regexp_match(citext, citext, text) owner to postgres;

