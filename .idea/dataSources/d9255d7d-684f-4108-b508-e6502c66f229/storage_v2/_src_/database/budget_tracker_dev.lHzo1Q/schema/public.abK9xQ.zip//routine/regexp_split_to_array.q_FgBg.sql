create function regexp_split_to_array(string citext, pattern citext) returns text[]
    immutable
    strict
    parallel safe
    language sql
RETURN regexp_split_to_array((string)::text, (pattern)::text, 'i'::text);

alter function regexp_split_to_array(citext, citext) owner to postgres;

