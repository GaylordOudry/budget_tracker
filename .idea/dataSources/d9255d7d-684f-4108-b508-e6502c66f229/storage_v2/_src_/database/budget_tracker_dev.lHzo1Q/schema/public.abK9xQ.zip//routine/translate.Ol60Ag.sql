create function translate(citext, citext, text) returns text
    immutable
    strict
    parallel safe
    language sql
RETURN translate(translate(($1)::text, lower(($2)::text), $3), upper(($2)::text), $3);

alter function translate(citext, citext, text) owner to postgres;

