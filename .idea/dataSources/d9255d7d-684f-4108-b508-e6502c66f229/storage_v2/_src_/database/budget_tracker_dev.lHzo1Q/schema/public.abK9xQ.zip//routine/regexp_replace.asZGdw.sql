create function regexp_replace(string citext, pattern citext, replacement text) returns text
    immutable
    strict
    parallel safe
    language sql
RETURN regexp_replace((string)::text, (pattern)::text, replacement, 'i'::text);

alter function regexp_replace(citext, citext, text) owner to postgres;

