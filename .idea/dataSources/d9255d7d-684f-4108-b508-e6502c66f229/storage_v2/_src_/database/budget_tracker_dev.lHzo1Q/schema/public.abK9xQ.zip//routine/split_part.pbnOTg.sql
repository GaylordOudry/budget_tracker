create function split_part(citext, citext, integer) returns text
    immutable
    strict
    parallel safe
    language sql
RETURN (regexp_split_to_array(($1)::text, regexp_replace(($2)::text, '([^a-zA-Z_0-9])'::text, '\\\1'::text, 'g'::text), 'i'::text))[$3];

alter function split_part(citext, citext, integer) owner to postgres;

