create function replace(citext, citext, citext) returns text
    immutable
    strict
    parallel safe
    language sql
RETURN regexp_replace(($1)::text, regexp_replace(($2)::text, '([^a-zA-Z_0-9])'::text, '\\\1'::text, 'g'::text), ($3)::text, 'gi'::text);

alter function replace(citext, citext, citext) owner to postgres;

