create function regexp_split_to_array(string citext, pattern citext, flags text) returns text[]
    immutable
    strict
    parallel safe
    language sql
RETURN regexp_split_to_array((string)::text, (pattern)::text, CASE WHEN (strpos(flags, 'c'::text) = 0) THEN (flags || 'i'::text) ELSE flags END);

alter function regexp_split_to_array(citext, citext, text) owner to postgres;

